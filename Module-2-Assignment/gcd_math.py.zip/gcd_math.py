import math

def greatestcomdom(a, b):
  return f'Greatest Common Denominator: {math.gcd(a, b)}'

print(greatestcomdom(2, 3))